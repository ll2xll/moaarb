--[[
جميع الحقوق محفوظه للمطور حموشي @MEDO_REAL
تابع قناتي : @API_CLI
--]]

local function run(msg, matches)
if matches[1] == "الطم" then
if msg.to.type == 'channel' or 'chat' then
local answers = {'طبعي كربلائي و استمع ندائي للموت و افتخر خادم يسموني للموت كربلة شايلهة بعيوني','المايطبر راسة لك يا حسين شلي براسة حسين شلي براسة حسين شلي براسة المايطبر راسة لك يحسين شلي براسة ','شيعي انا و اللطم شعاري شيعي انا و اللطم شعاري ','حسين كون ابجيلة دم حسين كون ابجيلة دم اري افهم المافهم حسين كو ابجيلة دم',' ياعباس جينة مشاية يا عباس خفت الراية يا عباس جينة مشاية يا عبا س خفت الراية','مابية حيل صوتي مطبك'}
return answers[math.random(#answers)]
end
end
end
return {
description = "Chat With Robot Server",
usage = "chat with robot",
patterns = {
"^الطم$"
},
run = run
}
