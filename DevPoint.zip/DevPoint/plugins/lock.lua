local function saeco(msg,matches)
local receiver = get_receiver(msg)
local bot_id = our_id
local add = "☹️Hi "..msg.from.first_name.." 🙂Only Devs Can invite me \n 🖕🏻🙂 Dont invite me again ☺️"
local warn = "🙂عزيزي المطور ".."\n"
.." هناك من حاول اضافتي الى مجموعة "
.."\n"
.." \n 👾 About That \n \n 📃Group Name "..msg.to.title.."\n"
.."\n 📌Group ID :("..msg.to.id..")\n 📥His Name : "..msg.from.first_name.."\n "
.."🆔 His ID :("..msg.from.id..")\n"
.." 🔑His Username :(@"..(msg.from.username or "Not Found")
..")\n 🏷 Im Leave From This Group "
local sudo = 96141153 -- set your id here
if msg.service and msg.action.type == "chat_add_user" and msg.action.user.id == tonumber(bot_id) and not is_sudo(msg) then
       send_large_msg(receiver, add, ok_cb, false)
       chat_del_user(receiver, 'user#id'..bot_id, ok_cb, false)
       channel_kick(receiver, 'user#id'..bot_id, ok_cb, false)
       leave_channel(receiver, ok_cb, false)
       send_large_msg("user#id"..sudo,warn)
       end
       end
       
       return {
  patterns = {
    "^!!tgservice (.+)$"
  },
  run = saeco
}
-- Dev By Saeco